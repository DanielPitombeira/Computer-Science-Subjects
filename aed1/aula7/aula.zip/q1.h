/*1-)

a-) Abstração é o ato de analizar e trazer aspectos não concretos para a realidade;
b-) Os tipos de dados definem as operações que serão feitas com uma 
determinada variável, e a quantidade de memória que será armazenada essa variável;
c-) Tipos abstratos de dados definem um tipo de dado de maneira abstrata, ou seja, 
sem revelar os detalhes de implementação interna, a sua interface, a complexidade, etc;
*/