#include <stdio.h>

void push1(int data);
void push2(int data);
void apaga_negativos();
void print();
