#include <stdio.h>
#include <stdlib.h>

struct node{
    double real;
    int prioridade;
    struct node* next;
};

typedef struct node node;

void enfileirar(double real, int prioridade);
void cria_fila1(node* temp);
void cria_fila2(node* temp);
void pop();
void divida_filas(int p);
void imprimir(int op);
