#include "q6.h"

node* front1 = NULL;
node* rear1 = NULL;

node* front2 = NULL;
node* rear2 = NULL;

node* front3 = NULL;
node* rear3 = NULL;

node* create_node(int data){
    node* no = malloc(sizeof(node));
    no->data = data;
    no->next = NULL;

    return no;
}

void queue(int data, int num){
    node* no;

    no = create_node(data);

    if(num == 1){
        if(front1 == NULL && rear1 == NULL){
            front1 = rear1 = no;
            return; 
        }
        rear1->next = no;
        rear1 = no;
    }else if(num == 2){
        if(front2 == NULL && rear2 == NULL){
            front2 = rear2 = no;
            return; 
        }
        rear2->next = no;
        rear2 = no;
    }else if(num == 3){
        if(front3 == NULL && rear3 == NULL){
            front3 = rear3 = no;
            return; 
        }
        rear3->next = no;
        rear3 = no;
    }
}

void pop(int num){
    if(num == 1){
        node* temp = front1;

        if(front1 == NULL){
            return;
        }else if(front1 == rear1){
            front1 = rear1 = NULL;
        }else{
            front1 = front1->next;
        }

        free(temp);
    }else if(num == 2){
        node* temp = front2;

        if(front2 == NULL){
            return;
        }else if(front2 == rear2){
            front2 = rear2 = NULL;
        }else{
            front2 = front2->next;
        }

        free(temp);
    }
}

void new_queue(){
    node* v = NULL;
    int n = 0;

    while(front1 != NULL){
        n++;
        node* temp = realloc(v, n * sizeof(node));

        v = temp;
        v[n-1].data = front1->data;

        pop(1);
    }

    while(front2 != NULL){
        n++;
        node* temp = realloc(v, n * sizeof(node));

        v = temp;
        v[n-1].data = front2->data;

        pop(2);
    }

    int aux;
    for(int i = 0; i < n; i++){
        for(int j = i+1; j < n; j++){
            if(v[i].data > v[j].data){
                aux = v[i].data;
                v[i].data = v[j].data;
                v[j].data = aux;
            }
        }
    }

    for(int i = 0; i < n; i++){
        queue(v[i].data, 3);
    }

}

void print(){
    node* temp = front3;

    while(temp != NULL){
        printf("%d\n", temp->data);

        temp = temp->next;
    }
}