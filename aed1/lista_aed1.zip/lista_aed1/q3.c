#include "q3.h"

node* front = NULL;
node* rear = NULL;

node* front1 = NULL; // fila 1 armazena valores menores ou iguais
node* rear1 = NULL;

node* front2 = NULL; //fila 2 armazena valores maiores
node* rear2 = NULL;

void enfileirar(double real, int prioridade){
    node* no;

    no = malloc(sizeof(node));
    no->real = real;
    no->prioridade = prioridade;
    no->next = NULL;

    if(front == NULL && rear == NULL){
        front = rear = no;
        return;
    }

    rear->next = no;
    rear = no;
}

void cria_fila1(node* temp){
    node* no = malloc(sizeof(node));
    no->real = temp->real;
    no->prioridade = temp->prioridade;
    no->next = NULL;

    if(front1 == NULL && rear1 == NULL){
        front1 = rear1 = no;
        return;
    }

    rear1->next = no;
    rear1 = no;
}

void cria_fila2(node* temp){
    node* no = malloc(sizeof(node));
    no->real = temp->real;
    no->prioridade = temp->prioridade;
    no->next = NULL;

    if(front2 == NULL && rear2 == NULL){
        front2 = rear2 = no;
        return;
    }

    rear2->next = no;
    rear2 = no;
}

void pop(){
    node* temp = front;
    if(front == NULL){
        return;
    }else if(front == rear){
        front = rear = NULL; 
    }else{
        front = front->next;
    }

    free(temp);
}

void divida_filas(int p){
    while(front != NULL){
        if(front->prioridade <= p){
            cria_fila1(front);
        }else{
            cria_fila2(front);
        }

        pop();
    }
}

void pop_fila(int op){
    if(op == 1){
        node* temp = front1;
        if(front1 == NULL){
            return;
        }else if(front1 == rear1){
            front1 = rear1 = NULL; 
        }else{
            front1 = front1->next;
        }

        free(temp);
    }else if(op == 2){
        node* temp = front2;
        if(front2 == NULL){
            return;
        }else if(front2 == rear2){
            front2 = rear2 = NULL; 
        }else{
            front2 = front2->next;
        }

        free(temp);
    }
}

void imprimir(int op){
    if(op == 1){
        node* temp = front1;
        while(temp != NULL){
            printf("%.2lf  %d\n",temp->real, temp->prioridade);

            temp = temp->next;
        }
    }else if(op == 2){
        node* temp = front2;
        while(temp != NULL){
            printf("%.2lf  %d\n",temp->real, temp->prioridade);

            temp = temp->next;
        }
    }
    
}