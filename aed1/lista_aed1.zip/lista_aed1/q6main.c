#include <stdio.h>
#include "q6.h"

void operacoes(int num){
    int op, data, aux = 0;

    while(1){
        printf("operacao: \n");
        printf("1- adicionar elemento\n");
        printf("2- sair\n");

        scanf("%d", &op);

        switch(op){
            case 1:
                printf("valor: \n");
                scanf("%d", &data);
                queue(data, num);
                break;
            case 2: 
                aux = 1;
                break;
            default: 
                printf("operacao invalida\n");
                break;
        }

        if(aux == 1)
            break;
    }
}

int main(){
    printf("Fila 1: \n");
    operacoes(1);

    printf("Fila 2: \n");
    operacoes(2);

    new_queue();
    print();

    return 0;
}