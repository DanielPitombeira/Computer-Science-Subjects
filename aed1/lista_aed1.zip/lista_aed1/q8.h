#include <stdio.h>
#include <stdlib.h>

struct node{
    int data;
    struct node* next;
};

typedef struct node node;

void push(int data);
node* create_node(int data);
void pop();
void operacao();