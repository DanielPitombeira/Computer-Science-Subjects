#include <stdio.h>
#include "q3.h"

int main(){
    int op, prioridade, aux = 0, p;
    double real;

    while(1){
        printf("Digite a operacao: \n");
        printf("1- adicionar elemento\n");
        printf("2- sair\n");
        scanf("%d", &op);

        switch(op){
            case 1:
                printf("valor real: ");
                scanf("%lf", &real);
                printf("valor inteiro: ");
                scanf("%d", &prioridade);
                enfileirar(real, prioridade);
                break;
            case 2:
                aux = 1;
                break;
            default:
                printf("valor invalido\n");
                break;
        }
        if(aux == 1)
        break;
    }

    printf("informe o valor p: ");
    scanf("%d", &p);

    divida_filas(p);

    printf("Fila 1: \n");
    imprimir(1);

    printf("Fila 2: \n");
    imprimir(2);

    return 0;
}