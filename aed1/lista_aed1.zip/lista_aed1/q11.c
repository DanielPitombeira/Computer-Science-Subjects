#include "q11.h"

node* front_impar = NULL;
node* rear_impar = NULL;

node* front_par = NULL;
node* rear_par = NULL;

node* stack = NULL;

node* create_node(int data){
    node* no;

    no = malloc(sizeof(node));
    no->data = data;
    no->next = NULL;

    return no;
}

void push_fila(int data, int num){
    node* no;

    no = create_node(data);

    if(num == 1){
        if(front_impar == NULL && rear_impar == NULL){
            front_impar = rear_impar = no;
            return;
        }

        rear_impar->next = no;
        rear_impar = no;
    }else if(num == 2){
        if(front_par == NULL && rear_par == NULL){
            front_par = rear_par = no;
            return;
        }

        rear_par->next = no;
        rear_par = no;
    }
}

void pop_fila(int num){
    node* temp;

    if(num == 1){
        temp = front_impar;
        
        if(front_impar == NULL){
            return;
        }else if(front_impar == rear_impar){
            front_impar = rear_impar = NULL;
        }else{
            front_impar = front_impar->next;
        }

        free(temp);
    }else if(num == 2){
        temp = front_par;
        
        if(front_par == NULL){
            return;
        }else if(front_par == rear_par){
            front_par = rear_par = NULL;
        }else{
            front_par = front_par->next;
        }

        free(temp);
    }
}

void push_pilha(int data){
    node* no;

    no = create_node(data);

    no->next = stack;
    stack = no;
}

void pop_pilha(){
    node* temp = stack;

    if(stack == NULL){
        return;
    }
    stack = stack->next;

    free(temp);
}

void funcao(){
    
    while(front_impar != NULL || front_par != NULL){
        if(front_impar != NULL){
            if(front_impar->data > 0){
                push_pilha(front_impar->data);
            }else{
                pop_pilha();
            }
            pop_fila(1);
        }
        if(front_par != NULL){
            if(front_par->data > 0){
                push_pilha(front_par->data);
            }else{
                pop_pilha();
            }
            pop_fila(2);
        }
    }
}

void print(){
    node* temp = stack;

    while(temp != NULL){
        printf("%d\n", temp->data);

        temp = temp->next;
    }
}